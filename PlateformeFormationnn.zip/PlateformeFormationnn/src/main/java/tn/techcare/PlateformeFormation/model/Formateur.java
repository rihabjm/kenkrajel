package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.util.List;




import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;

 
@Entity
@Table(name = "formateur")
public class Formateur  extends Utilisateur {
 
	private String cv ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "formateur", cascade = {CascadeType.ALL})
	private List<Certificats> certificat ;

	
	

	public List<Certificats> getCertificat() {
		return certificat;
	}

	public void setCertificat(List<Certificats> certificat) {
		this.certificat = certificat;
	}


	public List<Certificats> getCertificats() {
		return certificat;
	}

	public void setCertificats(List<Certificats> certificats) {
		this.certificat = certificats;
	}

	public String getCv() {
		return cv;
	}

	public void setCv(String cv) {
		this.cv = cv;
	}

	@Override
	public String toString() {
		return "Formateur [cv=" + cv + ", certificat=" + certificat +"]";
	}

	public Formateur() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Formateur(int id, String nom, String prenom, String adresse, int telephone, String login, String mdp,
			Date dateNAisse, String sexe, String gmail, String facebook, String linked, ImageModel image) {
		super(id, nom, prenom, adresse, telephone, login, mdp, dateNAisse, sexe, gmail, facebook, linked, image);
		// TODO Auto-generated constructor stub
	}





	
	
	
	
	
	
}
