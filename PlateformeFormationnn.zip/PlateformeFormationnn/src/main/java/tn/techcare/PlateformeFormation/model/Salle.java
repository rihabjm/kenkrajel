package tn.techcare.PlateformeFormation.model;

import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Salle")
public class Salle {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_salle ;
	private int  numsalle ;
	private int capacitesalle ;
	private boolean occupe ;
	
	
	
	public int getId_salle() {
		return id_salle;
		
	}
	

	@JsonIgnore
	@OneToMany(mappedBy = "salle", cascade = {CascadeType.ALL})
	private List<Seance> senace ;

	
	
	
	public void setId_salle(int id_salle) {
		this.id_salle = id_salle;
	}
	public int getNumsalle() {
		return numsalle;
	}
	public void setNumsalle(int numsalle) {
		this.numsalle = numsalle;
	}
	public int getCapacitesalle() {
		return capacitesalle;
	}
	public void setCapacitesalle(int capacitesalle) {
		this.capacitesalle = capacitesalle;
	}
	public boolean isOccupe() {
		return occupe;
	}
	public void setOccupe(boolean occupe) {
		this.occupe = occupe;
	}
	public List<Seance> getSenace() {
		return senace;
	}
	public void setSenace(List<Seance> senace) {
		this.senace = senace;
	}
	

	
}
