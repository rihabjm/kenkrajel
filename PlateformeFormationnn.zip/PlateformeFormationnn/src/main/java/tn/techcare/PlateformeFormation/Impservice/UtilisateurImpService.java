package tn.techcare.PlateformeFormation.Impservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.entites.PasswordDto;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.repository.UtilisateurRepository;
import tn.techcare.PlateformeFormation.service.UtilisateurService;


@Service
public class UtilisateurImpService  implements UtilisateurService{
	@Autowired
	private UtilisateurRepository userRepository;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub

		Utilisateur user = userRepository.findByLogin(username);

		return user ;
	}

	@Override
	public Utilisateur findById(int id) {
		// TODO Auto-generated method stub

		return userRepository.findById(id).orElse(null);	}

	@Override
	public Utilisateur findByEmail(String email) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				return userRepository.findByLogin(email);	}

	@Override
	public MessageResponse changePassword(PasswordDto passwordDto) {
		// TODO Auto-generated method stub
		Utilisateur user = userRepository.findById(passwordDto.getId()).orElse(null);
		if (user == null) {
			return new MessageResponse(false, "Utilisateur n'existe pas");
		}

		boolean valid = bCryptPasswordEncoder.matches(passwordDto.getOldPassword(), user.getPassword());
		if (!valid) {
			return new MessageResponse(false, "Ancien Mot de passe invalid");
		}
		String pwd = bCryptPasswordEncoder.encode(passwordDto.getNewPassword());

		user.setMdp(pwd);
		userRepository.save(user);

		return new MessageResponse(true, "Mot de passe modifi� avec succ�s");
	}

	
	
}
