package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.Certificats;
import tn.techcare.PlateformeFormation.model.MessageReponse;

 
public interface CertificatService {
	  public MessageReponse AjoutCertificats (Certificats Certif) ;
	  public List<Certificats> getAllCertificats();
	  public MessageReponse ModifierCertificats(Certificats Certif) ;
	  public MessageReponse SupprimerCertificats(int id_C);
	}
 
