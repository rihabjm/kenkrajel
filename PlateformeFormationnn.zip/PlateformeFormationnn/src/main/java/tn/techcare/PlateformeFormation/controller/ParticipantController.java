package tn.techcare.PlateformeFormation.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.zip.Deflater;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Participant;
import tn.techcare.PlateformeFormation.service.ParticipantService;

@CrossOrigin("*")
@RestController
@RequestMapping("/participant")
public class ParticipantController {

	@Autowired
	private  ParticipantService participantService ;
	
	@PostMapping("/add")
	private MessageReponse AjouterParticipant(@RequestBody Participant participant) {
		
		return participantService.AjouterParticipant(participant);
	}
  @GetMapping("/get")
  private List<Participant> getallParticipant()
  {
	  return participantService.getAllParticipant();
  }
  

@PutMapping("/update")
private MessageReponse ModifierParticipant (@RequestBody Participant participant ) {
	return participantService.ModifierParticipant(participant) ;
	
}


@DeleteMapping("{id}")
private MessageReponse SupprimerParticipant (@PathVariable("id") int id) {
	return participantService.SupprimerParticipant(id) ;
	}
	
@GetMapping("/bynom/{nom}")
private List<Participant> getbynom(@PathVariable("nom")String  nom) {
	return participantService.getParticipantByNom(nom);
	
}

@GetMapping("/byprenom/{prenom}")
private List<Participant> getbyprenom(@PathVariable("prenom")String  prenom) {
	return participantService.getParticipantByPrenom(prenom);
	
}


@GetMapping("/byadresse/{adresse}")
private List<Participant> getbyadresse(@PathVariable("adresse")String  adresse) {
	return participantService.getParticipantByAdresse(adresse);
}

@GetMapping("/bytel/{telephone}")
private List<Participant> getbytel(@PathVariable("telephone")int  telephone) {
	return participantService.getParticipantBytelephone(telephone);
}


@GetMapping("/bymail/{mail}")
private List<Participant> getbymail(@PathVariable("mail")String  mail) {
	return participantService.getParticipantByMail(mail) ;
}


@GetMapping("/bydatenaiss/{dateNAisse}")
private List<Participant> getbym(@PathVariable("dateNAisse")Date  dateNAisse) {
	return participantService.getParticipantByDateNAisse(dateNAisse);

}

public static byte[] compressBytes(byte[] data) {
	 
    Deflater deflater = new Deflater();

    deflater.setInput(data);

    deflater.finish();

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);

    byte[] buffer = new byte[1024];

    while (!deflater.finished()) {

        int count = deflater.deflate(buffer);

        outputStream.write(buffer, 0, count);

    }

    try {

        outputStream.close();

    } catch (IOException e) {

    }

    System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);

    return outputStream.toByteArray();

}



}
