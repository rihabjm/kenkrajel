package tn.techcare.PlateformeFormation.controller;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Certificats;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.service.CertificatService;
 

 
@CrossOrigin("*")
@RestController
@RequestMapping("/certif")
public class CertificatController {
	
	@Autowired
	private CertificatService certificatService ;
	
	@PostMapping("/add")
	private MessageReponse AjouterCertificat (@RequestBody Certificats Certif) {
		return certificatService.AjoutCertificats(Certif);
	}
	
  @GetMapping("/get")
  private List<Certificats> getAllCertificats()
  {
	  
	  return certificatService.getAllCertificats();
  }
  


@PutMapping("/update")
private MessageReponse ModifierCertificats (@RequestBody Certificats Certif ) {
	return certificatService.ModifierCertificats(Certif) ;
	
}


}