package tn.techcare.PlateformeFormation.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.entites.PasswordDto;
import tn.techcare.PlateformeFormation.model.Utilisateur;

public interface UtilisateurService extends UserDetailsService {
	
		Utilisateur findById(int id);

		Utilisateur findByEmail(String email);

		public MessageResponse changePassword(PasswordDto passwordDto);
}
