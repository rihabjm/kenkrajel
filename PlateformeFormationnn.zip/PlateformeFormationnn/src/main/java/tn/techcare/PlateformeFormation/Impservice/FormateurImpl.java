package tn.techcare.PlateformeFormation.Impservice;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.repository.FormateurRepository;
import tn.techcare.PlateformeFormation.repository.ImageRepository;
import tn.techcare.PlateformeFormation.repository.UtilisateurRepository;
import tn.techcare.PlateformeFormation.service.FormateurService;


 
@Service
@Transactional
public class FormateurImpl  implements FormateurService{

	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	  private  FormateurRepository fromateurRepository ;
	@Autowired
	  private  UtilisateurRepository utilisateurrepository ;
	@Autowired
	private ImageRepository imagerepository ;
	
	
	@Transactional
	@Override
	public MessageReponse AjoutFormateur(Formateur formateur) {
		// TODO Auto-generated method stub
	fromateurRepository.save(formateur);
	
		return  new MessageReponse(true, formateur.getId()+ "formateur est ajouter ") ;
	}

	
	
	@Override
	public List<Formateur> getAllFormateur() {
		// TODO Auto-generated method stub
		return (List<Formateur>) fromateurRepository.findAll();

	}
	@Transactional
	@Override
	public MessageReponse ModifierFormateur(Formateur formateur) {
		// TODO Auto-generated method stub
		
		Formateur formateur2 = fromateurRepository.findById(formateur.getId()).orElse(null);
		System.out.println(formateur2.getId());	

		if (formateur2!=null) 
		{
			fromateurRepository.save(formateur);
	           return new MessageReponse(true, "formateur modifiée");
		}
		       return new MessageReponse(false , "formateur introuvable");
	    }
	@Override
	public MessageReponse SupprimerFormateur(int id) {
		// TODO Auto-generated method stub
		Formateur formateur2 = fromateurRepository.findById(id).orElse(null) ;
	       if(formateur2== null) 
	       {
	       return new MessageReponse(false, "erreur , formateur introuvable");
	       }
	       fromateurRepository.delete(formateur2);
	         return new MessageReponse(true, "operation delet effectue avec succes");

	       }

	@Override
	public List<Formateur> getFormateurByNom(String nom) {
		// TODO Auto-generated method stub
	
		
	     List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByNom(nom);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}

	@Override
	public List<Formateur> getFormateurByPrenom(String prenom) {
		// TODO Auto-generated method stub
	
		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByPrenom(prenom);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}

	@Override
	public List<Formateur> getFormateurByAdresse(String adresse) {
		// TODO Auto-generated method stub

		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByAdresse(adresse);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}

	@Override
	public List<Formateur> getFormateurByMail(String mail) {
		// TODO Auto-generated method stub
		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByGmail(mail);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
	}

	@Override
	public List<Formateur> getFormateurByTelephone(int telephone) {
		// TODO Auto-generated method stub
		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByTelephone(telephone) ;
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}

	@Override
	public List<Formateur> getFormateurByDateNAisse(Date datenais) {
		// TODO Auto-generated method stub
		
		 List<Formateur> list =new ArrayList(); 
	     list =fromateurRepository.findFormateurByDateNAisse(datenais);
		
		if (list ==null ) {
			System.out.println("");
    }
		return list ;
			}

	@Override
	public Formateur getFormateurById(int id) {
	
		  
		Formateur formateur =fromateurRepository.findFormateurById(id) ;
		
		if (formateur ==null ) {
			System.out.println("");

		}
		return formateur ;
		
		
	}
	@Transactional
	@Override
	public MessageResponse save(Formateur formateur) {
		
	 
			Utilisateur list = utilisateurrepository.findByLoginAndId(formateur.getLogin(), formateur.getId());
			if (list == null) {
				list = utilisateurrepository.findByLogin(formateur.getLogin());
				if (list != null) {
					return new MessageResponse(false, "Email existant");
				}
			}

			String pwd = bCryptPasswordEncoder.encode(formateur.getPassword());
			formateur.setMdp(pwd);
			
		
		;
		fromateurRepository.save(formateur);

			return new MessageResponse(true, "Op�ration effectu�e avec succ�s");
		 
		
		
	}

	
		
	}
 
 