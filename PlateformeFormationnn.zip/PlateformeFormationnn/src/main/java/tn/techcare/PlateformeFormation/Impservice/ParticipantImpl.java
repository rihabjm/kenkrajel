package tn.techcare.PlateformeFormation.Impservice;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Participant;
import tn.techcare.PlateformeFormation.repository.ImageRepository;
import tn.techcare.PlateformeFormation.repository.ParticipantRepository;
import tn.techcare.PlateformeFormation.service.ParticipantService;
 
@Service
@Transactional
public class ParticipantImpl implements ParticipantService{
	@Autowired
	  private  ParticipantRepository participantRepository ;
	@Autowired
	private ImageRepository imagerepository ;
	
	@Transactional
	@Override
	public MessageReponse AjouterParticipant(Participant participant) {
	
		participantRepository.save(participant);
		return  new MessageReponse(true, participant.getId()+ "Participant est ajouter ") ;
	}

	@Override
	public List<Participant> getAllParticipant() {
		// TODO Auto-generated method stub
		return (List<Participant>) participantRepository.findAll();

	}
	@Transactional
	@Override
	public MessageReponse ModifierParticipant(Participant participant) {
		// TODO Auto-generated method stub
		Participant Participant2 = participantRepository.findById(participant.getId()).orElse(null);
		System.out.println(Participant2.getId());	

		if (Participant2!=null) 
		{
			participantRepository.save(participant);
	           return new MessageReponse(true, "Participant modifiée");
		}
		       return new MessageReponse(false , "Participant introuvable");
	    }

	@Override
	public MessageReponse SupprimerParticipant(int id_P) {
		// TODO Auto-generated method stub
		Participant Participant2 = participantRepository.findById(id_P).orElse(null) ;
	       if(Participant2== null) 
	       {
	       return new MessageReponse(false, "erreur , Participant introuvable");
	       }
	       participantRepository.delete(Participant2);
	         return new MessageReponse(true, "operation delet effectue avec succes");

	       }

	@Override
	public List<Participant> getParticipantByNom(String nom) {
		// TODO Auto-generated method stub
		
		 List<Participant> list =new ArrayList(); 
	     list =participantRepository.findParticipantByNom(nom);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}

	@Override
	public List<Participant> getParticipantByPrenom(String prenom) {
		// TODO Auto-generated method stub
	
		
		 List<Participant> list =new ArrayList(); 
	     list =participantRepository.findParticipantByPrenom(prenom);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
		
		
		
	}

	@Override
	public List<Participant> getParticipantByAdresse(String adresse) {
		// TODO Auto-generated method stub
		
		
		 List<Participant> list =new ArrayList(); 
	     list =participantRepository.findParticipantByAdresse(adresse);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
		
	}

	@Override
	public List<Participant> getParticipantByMail(String mail) {
		// TODO Auto-generated method stub
		 List<Participant> list =new ArrayList(); 
	     list =participantRepository.findParticipantByGmail(mail);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}


	@Override
	public List<Participant> getParticipantByDateNAisse(Date datenais) {
		// TODO Auto-generated method stub

		 List<Participant> list =new ArrayList(); 
	     list =participantRepository.findParticipantByDateNAisse(datenais);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}

	@Override
	public List<Participant> getParticipantBytelephone(int tel) {
		// TODO Auto-generated method stub
		 List<Participant> list =new ArrayList(); 
	     list =participantRepository.findParticipantByTelephone(tel);
		
		if (list ==null ) {
			System.out.println("");

		}
		return list ;
		
	}

	@Override
	public MessageResponse save(Participant participant) {
		// TODO Auto-generated method stub
		return null;
	}
		
	}

