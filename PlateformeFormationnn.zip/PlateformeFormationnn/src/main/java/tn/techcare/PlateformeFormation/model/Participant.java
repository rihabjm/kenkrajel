package tn.techcare.PlateformeFormation.model;



import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

 
@Entity
@Table(name = "Participant")
public class Participant  extends Utilisateur  {

	private String niveauEtude ;
	
	@JsonIgnore
	  @ManyToMany(cascade = CascadeType.ALL)
  @JoinTable(name = "particpantSession")
  private List<Session> session ;

	
	public String getNiveauEtude() {
		return niveauEtude;
	}

	public void setNiveauEtude(String niveauEtude) {
		this.niveauEtude = niveauEtude;
	}

	public List<Session> getSession() {
		return session;
	}

	public void setSession(List<Session> session) {
		this.session = session;
	}



	public Participant() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Participant(int id, String nom, String prenom, String adresse, int telephone, String login, String mdp,
			Date dateNAisse, String sexe, String gmail, String facebook, String linked, ImageModel image,
			String niveauEtude, List<Session> session) {
		super(id, nom, prenom, adresse, telephone, login, mdp, dateNAisse, sexe, gmail, facebook, linked, image);
		this.niveauEtude = niveauEtude;
		this.session = session;
	}
	
	
	
}
