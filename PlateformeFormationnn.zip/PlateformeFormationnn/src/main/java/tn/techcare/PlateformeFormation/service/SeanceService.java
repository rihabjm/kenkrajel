package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.sql.Time;
import java.util.List;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;


public interface SeanceService {
	

	 public MessageReponse AjouterSeance ( Time heuredeb ,Time heurefin ,int numeroseance,Date date ,Salle salle  ) ;
	  public List<Seance> getAllSeance();
	  public MessageReponse ModifierSeance(Seance senace) ;
	  public MessageReponse SupprimerSession(int id_senace);

}
