package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.Promotion;

public interface PromotionRepository extends JpaRepository<Promotion,Integer> {

}
