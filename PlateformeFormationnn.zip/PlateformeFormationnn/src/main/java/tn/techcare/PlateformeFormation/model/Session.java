package tn.techcare.PlateformeFormation.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Session")
public class Session {

	
	
	
	public Session() {
	
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int id_session ;
	private Date  datedebut ;
	private Date datefin ;
	
	private int nombrepartcipant ;
	
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "idformation")
	    private Formation formation  ;
	
	 @JsonIgnore
	 @ManyToMany(mappedBy="session")
	 private List<Participant> participants ;

	public int getId_session() {
		return id_session;
	}

	public void setId_session(int id_session) {
		this.id_session = id_session;
	}

	public Date getDatedebut() {
		return datedebut;
	}

	public void setDatedebut(Date datedebut) {
		this.datedebut = datedebut;
	}

	public Date getDatefin() {
		return datefin;
	}

	public void setDatefin(Date datefin) {
		this.datefin = datefin;
	}

	public int getNombrepartcipant() {
		return nombrepartcipant;
	}

	public void setNombrepartcipant(int nombrepartcipant) {
		this.nombrepartcipant = nombrepartcipant;
	}

	public Formation getFormation() {
		return formation;
	}

	public void setFormation(Formation formation) {
		this.formation = formation;
	}

	public List<Participant> getParticipants() {
		return participants;
	}

	public void setParticipants(List<Participant> participants) {
		this.participants = participants;
	}
	
	
	
}
