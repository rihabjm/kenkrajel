package tn.techcare.PlateformeFormation.model;

import java.beans.Transient;
import java.io.Serializable;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@Table(name = "utilisateur")
public class Utilisateur implements Serializable, UserDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int id ;
	 private String nom ;
	 private String prenom ;
	 private String adresse ;
	 private int telephone ;
	 private String login ;
	 private String mdp ;
	 private Date dateNAisse ; 
	 private String sexe ;
	 private String gmail ;
	 private String facebook ;
	 private String linked ;
 	 

		@OneToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "id_image")
	    private ImageModel image;
	   

	public String getLogin() {
			return login;
		}
		public void setLogin(String login) {
			this.login = login;
		}
		public String getMdp() {
			return mdp;
		}
		public void setMdp(String mdp) {
			this.mdp = mdp;
		}
		public String getGmail() {
			return gmail;
		}
		public void setGmail(String gmail) {
			this.gmail = gmail;
		}
		public String getFacebook() {
			return facebook;
		}
		public void setFacebook(String facebook) {
			this.facebook = facebook;
		}
		public String getLinked() {
			return linked;
		}
		public void setLinked(String linked) {
			this.linked = linked;
		}

	public ImageModel getImage() {
			return image;
		}
		public void setImage(ImageModel image) {
			this.image = image;
		}

	public Date getDateNAisse() {
		return dateNAisse;
	}
	public void setDateNAisse(Date dateNAisse) {
		this.dateNAisse = dateNAisse;
	}
 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public int getTelephone() {
		return telephone;
	}
	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}

	public String getSexe() {
		return sexe;
	}
	public void setSexe(String sexe) {
		this.sexe = sexe;
	}
	@JsonIgnore
	@Transient
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		Collection<GrantedAuthority> authorities = new ArrayList<>();
		if (this instanceof Admin ) {

			authorities.add(new SimpleGrantedAuthority("ROLE_Admin"));
		}

		if (this instanceof Formateur) {

			authorities.add(new SimpleGrantedAuthority("ROLE_Formateur"));
		}

		if (this instanceof Participant) {

			authorities.add(new SimpleGrantedAuthority("ROLE_Participant"));
		}
		return authorities;
	}
	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return mdp;
	}
	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return login;
		}
	
	@JsonIgnore
	@Transient
	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}
	
	@JsonIgnore
	@Transient
	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}
	@JsonIgnore
	@Transient
	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}
	@JsonIgnore
	@Transient
	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}
	public Utilisateur(int id, String nom, String prenom, String adresse, int telephone, String login, String mdp,
			Date dateNAisse, String sexe, String gmail, String facebook, String linked, ImageModel image) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.adresse = adresse;
		this.telephone = telephone;
		this.login = login;
		this.mdp = mdp;
		this.dateNAisse = dateNAisse;
		this.sexe = sexe;
		this.gmail = gmail;
		this.facebook = facebook;
		this.linked = linked;
		this.image = image;
	}
	public Utilisateur() {
		super();
		// TODO Auto-generated constructor stub
	}

		
	
	
	
	
	// TODO Auto-generated constructor stub
	}

	 
	 

