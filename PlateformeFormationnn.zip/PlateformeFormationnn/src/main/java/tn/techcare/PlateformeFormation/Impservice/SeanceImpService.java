package tn.techcare.PlateformeFormation.Impservice;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;
import tn.techcare.PlateformeFormation.repository.SalleRepository;
import tn.techcare.PlateformeFormation.repository.SeanceRepository;
import tn.techcare.PlateformeFormation.service.SeanceService;

@Service
@Transactional
public class SeanceImpService implements SeanceService {

	@Autowired
	private SeanceRepository  seancerepoistory;
	@Autowired
	private SalleRepository  sallerepoistory;
	
	@Override
	public MessageReponse AjouterSeance(Time heuredeb, Time heurefin, int numeroseance, Date date, Salle salle) {
	Seance seance = new Seance();
	
	seance.setDate(date);
	seance.setHeuredeb(heuredeb);
	seance.setHeurefin(heurefin);
	seance.setNumeroseance(numeroseance);
	seance.setSalle(salle);
	sallerepoistory.save(salle);
	seancerepoistory.save(seance) ;
   return new MessageReponse(true, seance.getId_seance()+ "senace est ajouter ") ;
	}

	@Override
	public List<Seance> getAllSeance() {
		
		return seancerepoistory.findAll();
	}

	@Override
	public MessageReponse ModifierSeance(Seance senace) {
		Seance	 seance2 = seancerepoistory.findById(senace.getId_seance()).orElse(null) ;
		if(seance2== null) {
		return new MessageReponse(false, "erreur , seance  introuvable");
		}
		seancerepoistory.save(seance2);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}

	@Override
	public MessageReponse SupprimerSession(int id_senace) {
		// TODO Auto-generated method stub
	
		Seance	 seance2 = seancerepoistory.findById(id_senace).orElse(null) ;
		if(seance2 == null) {
		return new MessageReponse(false, "erreur , Seance introuvable");
		}
		seancerepoistory.delete(seance2);
		return new MessageReponse(true, "operation delete effectue avec succes");
		
	}

}
