package tn.techcare.PlateformeFormation.Impservice;

import java.sql.Date;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Formation;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Participant;
import tn.techcare.PlateformeFormation.model.Session;
import tn.techcare.PlateformeFormation.repository.FormationRepository;
import tn.techcare.PlateformeFormation.repository.ParticipantRepository;
import tn.techcare.PlateformeFormation.repository.SessionRepository;
import tn.techcare.PlateformeFormation.service.SessionService;
@Service
@Transactional
public class SessionImpService implements SessionService  {
      
	@Autowired
	private SessionRepository  sessionrepoistory;
	@Autowired
	private ParticipantRepository particpantrepository;
	@Autowired
	private FormationRepository formationrepository ;
	
	
	
	@Override
	public MessageReponse AjouterSession( Session sessionn1) {
		/*for(int i=0;i<sessionn1.getParticipants().size();i++)
		{
			particpantrepository.save(sessionn1.getParticipants().get(i));
		}*/
	
		sessionrepoistory.save(sessionn1) ;
   return new MessageReponse(true, sessionn1.getId_session()+ "session est ajouter ") ;
	}

	@Override
	public List<Session> getAllSession() {
		// TODO Auto-generated method stub
		return  sessionrepoistory.findAll();
	}

	@Override
	public MessageReponse ModifierSession(Session sessionn1) {
		Session	 sessionn2 = sessionrepoistory.findById(sessionn1.getId_session()).orElse(null) ;
		if(sessionn2== null) {
		return new MessageReponse(false, "erreur , session  introuvable");
		}
		sessionrepoistory.save(sessionn1);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}

	@Override
	public MessageReponse SupprimerSession(int id_session) {
		Session session = sessionrepoistory.findById(id_session).orElse(null) ;
		if(session== null) {
		return new MessageReponse(false, "erreur , Session  introuvable");
		}
		sessionrepoistory.delete(session);
		return new MessageReponse(true, "operation delete effectue avec succes");
	}

}
