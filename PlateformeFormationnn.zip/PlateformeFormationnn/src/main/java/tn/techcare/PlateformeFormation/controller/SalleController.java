package tn.techcare.PlateformeFormation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.service.SalleService;
import tn.techcare.PlateformeFormation.model.Seance;

@CrossOrigin("*")
@RestController
@RequestMapping("/Salle")
public class SalleController {

	@Autowired
	private  SalleService salleservice ;
	
	@PostMapping("/add")
	public MessageReponse ajouterseance (@RequestBody Salle salle ){
	    
		return salleservice.AjouterSalle(salle);
	}
	
	@GetMapping("/get")
	public List<Salle>getAllSeance()
	{
		
     return salleservice.getAllSalle();
		
	}
	
	
	@PutMapping("/update")
	private MessageReponse updateformation (@RequestBody Salle  salle ) {
		return salleservice.ModifierSalle(salle);
		
	}

	@DeleteMapping("{id}")
	private MessageReponse deletSession (@PathVariable("id") int id) {
		return salleservice.SupprimerSalle(id) ;
		
	
}
}