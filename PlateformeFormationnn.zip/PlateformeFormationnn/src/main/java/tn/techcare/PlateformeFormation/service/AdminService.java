package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.model.Admin;
import tn.techcare.PlateformeFormation.model.MessageReponse;

public interface AdminService {
	  public MessageReponse AjoutAdmin (Admin admin) ;
	  public List<Admin> getAlladmin();
    public MessageReponse ModifierAdmin(Admin admin) ;
	  public MessageReponse SupprimerAdmin(int id);
	  public  Admin    getAdminById(int id);
	public MessageResponse save(Admin admin);
}
