package tn.techcare.PlateformeFormation.model;



import javax.persistence.Entity;

import javax.persistence.Table;





@Entity
@Table(name = "formationModule")
public class FormationModule extends Formation{

    private int nombreheure ;

	public int getNombreheure() {
		return nombreheure;
	}

	public void setNombreheure(int nombreheure) {
		this.nombreheure = nombreheure;
	}
    
}
