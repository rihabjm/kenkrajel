package tn.techcare.PlateformeFormation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.entites.PasswordDto;
import tn.techcare.PlateformeFormation.model.Admin;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Participant;
import tn.techcare.PlateformeFormation.model.Utilisateur;
import tn.techcare.PlateformeFormation.service.AdminService;
import tn.techcare.PlateformeFormation.service.FormateurService;
import tn.techcare.PlateformeFormation.service.ParticipantService;
import tn.techcare.PlateformeFormation.service.UtilisateurService;

@RestController
@RequestMapping("/utilisateur")
public class UtilisateurController {

	@Autowired
	private UtilisateurService userService;
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private ParticipantService participantService;
	
	@Autowired
	private FormateurService formateurService;

	/* @PutMapping("/profil")
	public MessageReponse changeProfile(@RequestBody Utilisateur user) {

		Utilisateur u = userService.findById(user.getId());

		if (u instanceof Participant ) {
			Participant particpant = new Participant(user.getId(), user.getNom(), user.getLogin(), user.getMdp(), null, user.getTelephone(),
					user.getAdresse(), null, null, null, null);
			return participantService.ModifierParticipant(particpant);
		} else if (u instanceof Admin) {

			Admin admin = new Admin(user.getId(), user.getNom(), user.getLogin(), user.getPassword(),
					null, user.getTelephone(), user.getAdresse(), null, null, null, null);
			return adminService.ModifierAdmin(admin);
		} else {
			Formateur formateur = new Formateur(user.getId(), user.getNom(), user.getLogin(), user.getPassword(),
					null, user.getTelephone(), user.getAdresse(), null, null, null, null);
			return formateurService.ModifierFormateur(formateur);
		}

	}*/

	@GetMapping("/{email}")
	public Utilisateur getUserByEmail(@PathVariable String email) {

		return userService.findByEmail(email);

	}

	@PutMapping("/pwd")
	public MessageResponse changePassword(@RequestBody PasswordDto pwd) {
		return userService.changePassword(pwd);
	}
	
	
}
