package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Salle;
import tn.techcare.PlateformeFormation.model.Seance;
import tn.techcare.PlateformeFormation.repository.SalleRepository;
import tn.techcare.PlateformeFormation.repository.SeanceRepository;
import tn.techcare.PlateformeFormation.service.SalleService;

@Service
@Transactional
public class SalleimpService implements SalleService {
	
	@Autowired
	private SalleRepository  sallerepoistory;

	@Autowired
	private SeanceRepository  seancerepoistory;

	@Override
	public List<Salle> getAllSalle() {
		// TODO Auto-generated method stub
		return sallerepoistory.findAll();
	}

	@Override
	public MessageReponse ModifierSalle(Salle salle) {
		// TODO Auto-generated method stub
		Salle	 salle1 = sallerepoistory.findById(salle.getId_salle()).orElse(null) ;
		if(salle1== null) {
		return new MessageReponse(false, "erreur , salle  introuvable");
		}
		sallerepoistory.save(salle);
		return new MessageReponse(true, "operation modifier effectue avec succes");
	}
	

	@Override
	public MessageReponse SupprimerSalle(int id_salle) {
		// TODO Auto-generated method stub
		Salle	 salle1 = sallerepoistory.findById(id_salle).orElse(null) ;
		if(salle1== null) {
		return new MessageReponse(false, "erreur , salle  introuvable");
		}
		sallerepoistory.delete(salle1);
		return new MessageReponse(true, "operation delet  effectue avec succes");
	}

	@Override
	public MessageReponse AjouterSalle(Salle salle) {
		// TODO Auto-generated method stub
	  sallerepoistory.save(salle);
	 return new MessageReponse(true, salle.getId_salle()+ "salle est ajouter ") ;
	}

}
