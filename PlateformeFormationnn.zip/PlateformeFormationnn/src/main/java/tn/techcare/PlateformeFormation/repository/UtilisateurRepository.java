package tn.techcare.PlateformeFormation.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.Utilisateur;


public interface UtilisateurRepository extends JpaRepository<Utilisateur, Integer> {
	
	Utilisateur  findByLogin(String login);

	Utilisateur  findByLoginAndId(String login , Integer id);



}
