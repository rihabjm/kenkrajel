package tn.techcare.PlateformeFormation.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.model.Admin;
import tn.techcare.PlateformeFormation.model.Formateur;
import tn.techcare.PlateformeFormation.model.Participant;
import tn.techcare.PlateformeFormation.service.AdminService;
import tn.techcare.PlateformeFormation.service.FormateurService;
import tn.techcare.PlateformeFormation.service.ParticipantService;



@RestController
@RequestMapping("/register")
public class RegisterController {
		
	
	
	@Autowired
	private ParticipantService participantService;
	
	@Autowired
	private FormateurService formateurService ; 
	
	@Autowired
	private AdminService adminService ; 
	
	@PostMapping
	public MessageResponse save(@RequestBody Participant participant) {
		return participantService.save(participant);
	}
	@PostMapping ("/gestion")
	public MessageResponse savegestionnaire (@RequestBody Formateur formateur) {
		return formateurService.save(formateur);
	}
	@PostMapping("/admin")
	public MessageResponse save(@RequestBody Admin admin) {
		return adminService.save(admin);}
		
	


	
}
