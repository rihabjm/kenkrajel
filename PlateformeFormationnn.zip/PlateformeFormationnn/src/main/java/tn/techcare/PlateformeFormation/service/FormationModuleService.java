package tn.techcare.PlateformeFormation.service;


import java.sql.Date;

import java.util.List;
import java.util.Optional;

import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.MessageReponse;

public interface FormationModuleService {
	public MessageReponse ajoutFormationModule (FormationModule formation) ;
	public List<FormationModule>getAllFormation();
	public MessageReponse updateFormation(FormationModule formation) ;
	public MessageReponse supprimerFormation( int id);
	public List<FormationModule> getformationbytype(String type ) ;
	public List<FormationModule> getformationbyEtat(String etat ) ;
    public List<FormationModule> getformationbyintitule(String intitule ) ;
	public List<FormationModule> getformationbydatedebut(Date datedeb ) ;
	public List<FormationModule> getformationbydatefin(Date datefin ) ;
	public List<FormationModule> getformationbyPrix(float prix ) ;
	public List<FormationModule> getformationbyNombreheure(int nbr ) ;
	public List<FormationModule> getformationbySession(String session ) ;
	public FormationModule  getformationbyId(int id ) ;

	
	
}
