package tn.techcare.PlateformeFormation.controller;

import java.io.ByteArrayOutputStream;

import java.io.IOException;
import java.sql.Date;
import java.util.List;
import java.util.Optional;
import java.util.zip.Deflater;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.service.FormationModuleService;


@CrossOrigin("*")
@RestController
@RequestMapping("/formationModule")
public class FormationModuleController {
	
	
	@Autowired
	private  FormationModuleService formationModuleService ;
	
	@PostMapping("/add")
	public MessageReponse ajouterreunion (@RequestBody FormationModule formationmodule ) {
	   
		return formationModuleService.ajoutFormationModule(formationmodule);
	}
	
	@GetMapping("/get")
	public List<FormationModule>getAllFormation()
	{
		
     return formationModuleService.getAllFormation() ;
		
	}
	
	@PutMapping("/update")
	private MessageReponse updateformation (@RequestBody FormationModule  formation ) {
		return formationModuleService.updateFormation(formation) ;
		
	}

	@DeleteMapping("{id}")
	private MessageReponse deletformation (@PathVariable("id") int id) {
		return formationModuleService.supprimerFormation(id) ;
		
	}
	  
	@GetMapping("/bytype/{type}")
	private List<FormationModule> getbytype(@PathVariable("type")String  type) {
		return formationModuleService.getformationbytype(type);
		
	}
	
	@GetMapping("/byetat/{etat}")
	private List<FormationModule> getbyetat(@PathVariable("etat")String  etat) {
		return formationModuleService.getformationbyEtat(etat);
		
	}
	
	@GetMapping("/byintitule/{intitule}")
	private List<FormationModule> getbyintitule(@PathVariable("intitule")String  intitule) {
		return formationModuleService.getformationbyintitule(intitule) ;
		
	}
	
	@GetMapping("/bydatedeb/{datedebut}")
	private List<FormationModule> getbydatedebut(@PathVariable("datedebut")Date  datedebut) {
		return formationModuleService.getformationbydatedebut(datedebut);
		
	}
	@GetMapping("/bydatefin/{datefin}")
	private List<FormationModule> getbydatefin(@PathVariable("datefin")Date  datefin) {
		return formationModuleService.getformationbydatefin(datefin);
		
	}

	@GetMapping("/byprix/{prix}")
	private List<FormationModule> getbyprix(@PathVariable("prix")float  prix) {
		return formationModuleService.getformationbyPrix(prix);
		
	}
	
	@GetMapping("/bynbrheure/{nombreheure}")
	private List<FormationModule> getbynombreheure(@PathVariable("nombreheure")int  nombreheure) {
		return formationModuleService.getformationbyNombreheure(nombreheure);
		
	}
	
	@GetMapping("/byid/{id}")
	private   FormationModule  getbyId(@PathVariable("id")int  id) {
		return formationModuleService.getformationbyId(id) ;
	
	}
  
	
	@GetMapping("/bysession/{session}")
	private List<FormationModule> getbynombreheure(@PathVariable("session")String  session) {
		return formationModuleService.getformationbySession(session);
		
	}
	
	
	
	public static byte[] compressBytes(byte[] data) {
		 
	    Deflater deflater = new Deflater();

	    deflater.setInput(data);

	    deflater.finish();

	    ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);

	    byte[] buffer = new byte[1024];

	    while (!deflater.finished()) {

	        int count = deflater.deflate(buffer);

	        outputStream.write(buffer, 0, count);

	    }

	    try {

	        outputStream.close();

	    } catch (IOException e) {

	    }

	    System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);

	    return outputStream.toByteArray();

	}
}
