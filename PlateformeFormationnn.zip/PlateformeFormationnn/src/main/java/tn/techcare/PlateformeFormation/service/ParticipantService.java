package tn.techcare.PlateformeFormation.service;

import java.sql.Date;
import java.util.List;

import tn.techcare.PlateformeFormation.entites.MessageResponse;
import tn.techcare.PlateformeFormation.model.ImageModel;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.model.Participant;

public interface ParticipantService {
	 public MessageReponse AjouterParticipant (Participant participant) ;
	  public List<Participant> getAllParticipant();
	  public MessageReponse ModifierParticipant(Participant participant) ;
	  public MessageReponse SupprimerParticipant(int id_P);
	    List<Participant> getParticipantByNom(String nom ) ;
		List<Participant> getParticipantByPrenom(String prenom ) ;
		List<Participant>  getParticipantByAdresse(String adresse ) ;
		List<Participant> getParticipantByMail(String mail ) ;
        List<Participant> getParticipantByDateNAisse(Date datenais ) ;
        List<Participant> getParticipantBytelephone(int tel ) ;
		public MessageResponse save(Participant participant);

		
}
