package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.Certificats;


 
public interface CertificatRepository extends JpaRepository<Certificats,Integer> {

}
