package tn.techcare.PlateformeFormation.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class Admin extends Utilisateur  {

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(int id, String nom, String prenom, String adresse, int telephone, String login, String mdp,
			Date dateNAisse, String sexe, String gmail, String facebook, String linked, ImageModel image) {
		super(id, nom, prenom, adresse, telephone, login, mdp, dateNAisse, sexe, gmail, facebook, linked, image);
		// TODO Auto-generated constructor stub
	}



}
