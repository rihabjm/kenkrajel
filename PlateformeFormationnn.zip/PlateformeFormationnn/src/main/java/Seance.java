
public class Seance {

}
